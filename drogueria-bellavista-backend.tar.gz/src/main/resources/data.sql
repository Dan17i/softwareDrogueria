-- Script SQL para datos de prueba
-- Ejecuta esto después de que Spring cree las tablas

-- Productos de ejemplo
INSERT INTO products (code, name, description, price, stock, min_stock, category, active, created_at, updated_at) VALUES
('MED001', 'Acetaminofén 500mg', 'Analgésico y antipirético en tabletas', 5000.00, 150, 30, 'Medicamentos', true, NOW(), NOW()),
('MED002', 'Ibuprofeno 400mg', 'Antiinflamatorio no esteroideo', 8000.00, 80, 20, 'Medicamentos', true, NOW(), NOW()),
('MED003', 'Omeprazol 20mg', 'Inhibidor de la bomba de protones', 12000.00, 60, 15, 'Medicamentos', true, NOW(), NOW()),
('MED004', 'Loratadina 10mg', 'Antihistamínico para alergias', 6500.00, 100, 25, 'Medicamentos', true, NOW(), NOW()),
('MED005', 'Amoxicilina 500mg', 'Antibiótico de amplio espectro', 15000.00, 45, 20, 'Medicamentos', true, NOW(), NOW()),

('VIT001', 'Vitamina C 1000mg', 'Suplemento vitamínico', 18000.00, 120, 30, 'Vitaminas', true, NOW(), NOW()),
('VIT002', 'Vitamina D3 2000 UI', 'Suplemento de vitamina D', 22000.00, 70, 20, 'Vitaminas', true, NOW(), NOW()),
('VIT003', 'Complejo B', 'Vitaminas del complejo B', 16000.00, 90, 25, 'Vitaminas', true, NOW(), NOW()),

('COS001', 'Protector Solar FPS 50+', 'Protección UV de amplio espectro', 35000.00, 40, 15, 'Cosméticos', true, NOW(), NOW()),
('COS002', 'Crema Hidratante Facial', 'Hidratación profunda para todo tipo de piel', 28000.00, 55, 15, 'Cosméticos', true, NOW(), NOW()),
('COS003', 'Shampoo Anticaspa', 'Tratamiento contra la caspa', 18000.00, 65, 20, 'Cosméticos', true, NOW(), NOW()),

('HIG001', 'Alcohol Antiséptico 70%', 'Desinfectante de manos y superficies', 8000.00, 200, 50, 'Higiene', true, NOW(), NOW()),
('HIG002', 'Gel Antibacterial 500ml', 'Desinfectante de manos sin agua', 12000.00, 150, 40, 'Higiene', true, NOW(), NOW()),
('HIG003', 'Tapabocas Quirúrgico x50', 'Protección facial desechable', 25000.00, 80, 30, 'Higiene', true, NOW(), NOW()),
('HIG004', 'Guantes de Látex x100', 'Guantes desechables para uso médico', 30000.00, 60, 25, 'Higiene', true, NOW(), NOW()),

('BEB001', 'Suero Oral 500ml', 'Rehidratación oral', 6000.00, 100, 30, 'Bebidas', true, NOW(), NOW()),
('BEB002', 'Agua Destilada 1L', 'Agua purificada para uso médico', 4000.00, 120, 35, 'Bebidas', true, NOW(), NOW()),

('EQU001', 'Termómetro Digital', 'Medición de temperatura corporal', 25000.00, 30, 10, 'Equipos', true, NOW(), NOW()),
('EQU002', 'Tensiómetro Digital', 'Medición de presión arterial', 80000.00, 15, 5, 'Equipos', true, NOW(), NOW()),
('EQU003', 'Glucómetro con 50 Tiras', 'Medición de glucosa en sangre', 120000.00, 10, 3, 'Equipos', true, NOW(), NOW());

-- Productos con stock bajo (para probar la funcionalidad de reabastecimiento)
INSERT INTO products (code, name, description, price, stock, min_stock, category, active, created_at, updated_at) VALUES
('MED006', 'Aspirina 100mg', 'Antiagregante plaquetario', 7000.00, 15, 20, 'Medicamentos', true, NOW(), NOW()),
('VIT004', 'Calcio + Vitamina D', 'Suplemento para huesos', 20000.00, 8, 15, 'Vitaminas', true, NOW(), NOW()),
('COS004', 'Desodorante Roll-on', 'Protección 48 horas', 12000.00, 10, 20, 'Cosméticos', true, NOW(), NOW());

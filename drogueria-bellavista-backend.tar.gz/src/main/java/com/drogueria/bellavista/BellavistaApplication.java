package com.drogueria.bellavista;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BellavistaApplication {

    public static void main(String[] args) {
        SpringApplication.run(BellavistaApplication.class, args);
    }
}
